
public class NodoArista {
    
    NodoGrafo direccion;
    NodoArista sig, ant;
    
    public NodoArista(NodoGrafo destino){
        direccion=destino;
        sig=ant=null; 
    }
    
}
