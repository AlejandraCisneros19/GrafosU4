
public class PGrafo {
    
    private NodoGrafo ini,fin;
    
    public PGrafo(){
        ini=null;
        fin=null;
    }
    
    public boolean insertarNodoGrafo(char v){
        
        NodoGrafo nuevo= new NodoGrafo(v);
        
        if(nuevo==null){
            return false;
        }
        
       if(ini==null && fin==null){
           ini=fin=nuevo;
           return true;
       }
       fin.sig=nuevo;
       nuevo.ant=fin;
       fin=nuevo;
       
       return true; 
    }
    
    public boolean insertarArista(char orig, char dest){
        NodoGrafo origen = buscarNodoGrafo(orig);
        
        if(origen==null){
            return false;
        }
        NodoGrafo destino=buscarNodoGrafo(dest);
        if(destino==null){
            return false;
        }
        NodoArista temp= new NodoArista(destino);
        if(temp==null){
        }
        if(origen.arista==null){
            origen.arista=temp;
            return true;
        }
        NodoArista t2 = origen.arista;
        //este ciclo avanza a t2 hasta que llega al ultimo nodo de lista arista
        while(t2.sig!=null){
            t2=t2.sig;
        }
        t2.sig=temp;
        temp.ant=t2;
        
        return true;
    }
    
    private NodoGrafo buscarNodoGrafo(char valorBuscado){
        NodoGrafo temp=ini;
        
        do{
            if(temp.valor==valorBuscado){
                return temp;
            }
            temp=temp.sig;
        }while(temp!=null);
        
        return temp;
    }
    
    public boolean eliminarArista(char orig, char dest){
        NodoGrafo origen = buscarNodoGrafo(orig);
        
        if(origen==null){
            return false;
        }
        if(origen.arista==null){
            return false;
        }
        NodoArista temp = origen.arista;
        do{
            if(temp.direccion.valor==dest){
                if(temp==origen.arista){
                    origen.arista=temp.sig;
                    temp.direccion=null;
                    temp.sig=null;
                    origen.arista.ant=null;
                    return true;
                }else{
                    //revisar si la arista a ELIMINAR esta como ultimo nodo
                    if(temp.sig==null){
                        temp.ant.sig=null;
                        temp.direccion=null;
                        temp.ant=null;
                        return true;
                    }
                    //desconectar la arista a eliminar estando en medio
                    temp.ant.sig=temp.sig;//el puntero SIG de nodo ARRIBA(temp.ant) lo enlazo con nodo ABAJO(temp.sig)
                    temp.sig.ant=temp.ant;//el puntero ant de ARRIBA (temp.sig) lo enlazo con nodo ABAJO(temp.ant)
                    temp.sig=temp.ant=null;
                    temp.direccion=null;
                    return true;
                }
            }
            temp=temp.sig;
        }while(temp!=null);
        
        return false;
    }
    
    public boolean eliminarNodo(char v){
        if(ini==null && fin==null){
            return false;
        }
        NodoGrafo nodoAEliminar = buscarNodoGrafo(v);
        if(nodoAEliminar==null){
            return false;
        }
        //VERIFICAR SI ES ISLA EL NODO A ELIMINAR 
        //CASO 1: QUE EL NO TENGA ARISTAS
        if(nodoAEliminar.arista != null){
            return false;
        }
        //CASO 2: QUE OTRO NODO NO TENGA ARISTAS A NODO ELIMINAR
        for(NodoGrafo temp=ini; temp!=null; temp=temp.sig){
            if(encontrarAristas(temp, nodoAEliminar)==true){
                return false;
            }
        }
        if(ini==fin && ini==nodoAEliminar){
            ini=fin=null;
            return true;
        }
        //ELIMINANDO SI EL NODO A ELIMINAR ESTA EN INI
        if(ini==nodoAEliminar){
            NodoGrafo temp = ini.sig;
            ini.sig=null;
            temp.ant=null;
            ini=temp;
            return true;
        }
        //ELIMINANDO SI EL NODO A ELIMINAR ESTA EN FIN
        if(fin==nodoAEliminar){
            NodoGrafo temp = fin.ant;
            temp.sig=null;
            fin.ant=null;
            fin=temp;
            return true;
        }
        //ELIMINANDO SI EL NODO A ELIMINAR ESTA EN MEDIO
        nodoAEliminar.ant.sig=nodoAEliminar.sig;
        nodoAEliminar.sig.ant=nodoAEliminar.ant;
        nodoAEliminar.sig=nodoAEliminar.ant=null;
        return true;
        
    }
    private boolean encontrarAristas(NodoGrafo temp, NodoGrafo nodoAEliminar){
        for(NodoArista temp2=temp.arista; temp2!=null; temp2=temp2.sig){
            if(temp2.direccion==nodoAEliminar){
                return true;
            }
        }
        return false;
    }
    
    public String mostrar(){
        if(ini==null && fin== null){
            return "NO HAY NODOS";
        }
        return mostrar(ini);
    }
    private String mostrar(NodoGrafo temp){
        if(temp==null){
            return "";
        }
        return temp.valor+ "\n" + mostrar(temp.sig);
    }
    
    public boolean encontrarArista(char orig,char dest){
        NodoGrafo origen = buscarNodoGrafo(orig);
        if(origen == null){
            return false;
        }
        if(origen.arista == null){
            return false;
        }
        NodoArista temp = origen.arista;
        if(temp.direccion.valor == dest){
            return true;
        }
        return false;
    }
}



