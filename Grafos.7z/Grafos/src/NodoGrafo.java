
public class NodoGrafo {
    
    char valor;
    NodoGrafo sig, ant;
    NodoArista arista;
    
    public NodoGrafo(char v){
        valor=v;
        sig=ant=null;
        arista=null;
    }
    
}
